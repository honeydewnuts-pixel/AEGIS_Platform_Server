AEGIS V39 EURUSD 36M FROZEN TRANSFER
Coverage: 2023-09-01 through 2026-08-28
V31 Validation: 458 trades, PF 0.9317487248; Final Test: 454 trades, PF 1.3156806431; REJECTED
V35 Validation: 358 trades, PF 1.1248443953; Final Test: 409 trades, PF 1.0909711975; REJECTED
Gates: Validation >=300 and PF >1.60; Final Test >=300 and PF >1.60. No tuning or gate changes.
